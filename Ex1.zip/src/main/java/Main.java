// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nota = -1;
        
        while (nota < 0 || nota > 10) {
            System.out.print("Digite um número entre 0 e 10: "); 
            nota = scanner.nextInt(); 
            
            if (nota < 0 || nota > 10) {
                System.out.println("Nota inválida, tente novamente."); 
            }
        }
        
        System.out.println("A nota digitada é: " + nota);

        scanner.close();
    }
}

